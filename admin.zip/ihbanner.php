<!--------------------- banner desktop starts --------------------------> 
<div class="container-fluid fluid0 bannertop px-0"> 
 <div id="carouselExampleIndicators" class="carousel slide d-none d-lg-block" data-bs-ride="carousel" data-bs-pause="false">   
  <div class="carousel-indicators"> 
   <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>    
   <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>    
   <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>  
  </div>   
  <div class="carousel-inner">    
   <div class="carousel-item active">
    <img src="img/hbanner02.jpg" class="d-block w-100 animated" alt="...">
    <div class="carousel2head animated fadeInLeft d-flex" style="visibility: visible;animation-delay: 0.1s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Perfect Natural</h1>
	</div>

    <div class="carousel2subhead01 animated fadeInLeft d-flex" style="visibility: visible;animation-delay: 0.1s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Bag Solution</h1>
	</div> 

	<div class="carousel2subhead animated fadeInLeft" style="visibility: visible;animation-delay: 0.5s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Through Innovation</h1>
	</div>
	
	<div class="carousel2subhead02 animated fadeInLeft" style="visibility: visible;animation-delay: 0.5s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">& Collaboration</h1>
	</div>
   </div>

   <div class="carousel-item">
    <img src="img/hbanner03.jpg" class="d-block w-100 animated" alt="...">
    <div class="carousel3head animated fadeInLeft d-flex" style="visibility: visible;animation-delay: 0.1s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Perfect Natural</h1>
	</div>

    <div class="carousel3subhead01 animated fadeInLeft d-flex" style="visibility: visible;animation-delay: 0.1s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Bag Solution</h1>
	</div> 

	<div class="carousel3subhead animated fadeInLeft" style="visibility: visible;animation-delay: 0.5s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Through Innovation</h1>
	</div>
	
	<div class="carousel3subhead02 animated fadeInLeft" style="visibility: visible;animation-delay: 0.5s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">& Collaboration</h1>
	</div>
   </div>

   <div class="carousel-item">
    <img src="img/hbanner01.jpg" class="d-block w-100 animated" alt="...">
    <div class="carouselhead animated fadeInLeft d-flex" style="visibility: visible;animation-delay: 0.1s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Perfect Natural</h1>
	</div>

    <div class="carouselsubhead01 animated fadeInLeft d-flex" style="visibility: visible;animation-delay: 0.1s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Bag Solution</h1>
	</div> 

	<div class="carouselsubhead animated fadeInLeft" style="visibility: visible;animation-delay: 0.5s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">Through Innovation</h1>
	</div>
	
	<div class="carouselsubhead02 animated fadeInLeft" style="visibility: visible;animation-delay: 0.5s;animation-name: fadeInLeft;">
	 <h1 class="mb-0">& Collaboration</h1>
	</div>
   </div>

  </div>  
  
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">   
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>    
   <span class="visually-hidden">Previous</span>   
  </button>   
  
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">    
  <span class="carousel-control-next-icon" aria-hidden="true"></span>    
  <span class="visually-hidden">Next</span>   
  </button> 
 </div>
</div>
  <!------------------------ banner desktop Ends -------------------------->
  <!--------------------- banner mobile starts ---------------------------->
  <div id="carouselExampleIndicators" class="carousel slide d-block d-lg-none" data-bs-ride="carousel" data-bs-pause="false"> 
   <div class="carousel-inner">  
    <div class="carousel-item active">   
	 <img src="img/mhbanner02.jpg" class="d-block w-100 animated" alt="">  
	</div> 
	<div class="carousel-item">   
	 <img src="img/mhbanner03.jpg" class="d-block w-100 "  alt="">  
	</div>  
	<div class="carousel-item">   
	 <img src="img/mhbanner01.jpg" class="d-block w-100" alt="">  
	</div>
   </div>
  </div>
<!------------------------ banner mobile Ends ---------------------------->