 <div class="bd-l bd-3 bd-danger bg-gray-200 pd-x-20 pd-y-25 mg-t-70 mg-b-50">
  <h5 class="tx-danger">Oh Sorry! Data is not yet added.</h5>
  <p class="mg-b-0">Please add data to make the CRM working</p>
 </div>