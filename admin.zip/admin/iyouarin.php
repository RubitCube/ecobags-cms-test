<div class="br-pageheader pd-y-15 pd-l-20 br-header-right">
 <nav class="breadcrumb pd-0 mg-0 tx-12">
  <!--<a class="breadcrumb-item" href="dashboard.php">Home</a>-->
  <?if ($youarein1<>"") { ?>
   <a class="breadcrumb-item" <?if ($youarein1link<>"") {?>href="<?echo $youarein1link?>"<?}?>><?echo $youarein1?></a>
  <?}?>
  <?if ($youarein2<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein2link<>"") {?>href="<?echo $youarein2link?>"<?}?>><?echo $youarein2?></a>
  <?}?>
  <?if ($youarein3<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein3link<>"") {?>href="<?echo $youarein3link?>"<?}?>><?echo $youarein3?></a>
  <?}?>
  <?if ($youarein4<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein4link<>"") {?>href="<?echo $youarein4link?>"<?}?>><?echo $youarein4?></a>
  <?}?>
  <?if ($youarein5<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein5link<>"") {?>href="<?echo $youarein5link?>"<?}?>><?echo $youarein5?></a>
  <?}?>
  <?if ($youarein6<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein6link<>"") {?>href="<?echo $youarein6link?>"<?}?>><?echo $youarein6?></a>
  <?}?>
  <?if ($youarein7<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein7link<>"") {?>href="<?echo $youarein7link?>"<?}?>><?echo $youarein7?></a>
  <?}?>
  <?if ($youarein8<>"") {?>
   <a class="breadcrumb-item" <?if ($youarein8link<>"") {?>href="<?echo $youarein8link?>"<?}?>><?echo $youarein8?></a>
  <?}?>
  <?if ($youareinname<>"") {?>
   <span class="breadcrumb-item active"><?echo $youareinname?></span>
  <?}?>
 </nav>
</div>