 <footer class="br-footer">
  <div class="footer-left">
   <div class="mg-b-2">Copyright &copy; <?echo date("Y")?>. <a href="http://www.ciber.ae">www.ciber.ae</a> All Rights Reserved.</div>
   <div>Attentively and carefully made by Cibernets.</div>
  </div>
  <div class="footer-right d-flex align-items-center">
   <div class="row mx-0 float-right">
    <font class=" text-right mg-r-4">design by<br><a target="_blank" href="https://www.ciber.ae">www.ciber.ae</a></font>
    <a target="_blank" href="https://www.ciber.ae"><img width="33" height="35" border="0" src="img/ciber.png" class="ciberimg"></a>
   </div>
  </div>
 </footer>